# BAI 2 Nhập vào số nguyên dương n. Viết chương trình phân tích số n thành các thừa so nguyen to 

n = int(input("nhap so nguyen duong n: "))
factor = set()
def thua_so_nt(n):
    while n% 2==0:
        factor.add(2)
        n//=2
    for i in range(3,int(math.sqrt(n))+1,2):
        while n%i==0:
            factor.add(i)
            n//=i
    if n>2 :
        factor.add(n)

    return factor

print (f"cac thua so nguyen to cua {n} la {thua_so_nt(n)}")