# (217CONTAINS DUPLICATE)Given an integer array nums, return true if any value appears at least twice in the array,
#  and return false if every element is distinct.

class Solution:
    def containsDuplicate(self, nums: list[int]) -> bool:
        list_nums = set()  
        for i in nums :
            if i in list_nums:
                return True
            list_nums.add(i)
        return False  
            