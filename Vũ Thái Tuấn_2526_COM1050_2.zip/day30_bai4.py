# 169 myjorityElement
class Solution:
    def majorityElement(self, nums: list[int]) -> int:
        frequency_dict = {}
        for i in nums :
            frequency_dict[i] = frequency_dict.get(i ,0 )+1 
        for key in frequency_dict:
            if frequency_dict[key] > len(nums)/2 :
                return(key)
