# BAI 3 so cách phân tích n thành tổng của hai số nguyên dương

n = int(input("nhap so nguyen duong n "))
if n <=1 :
    print("so cac phan tich la 0")
elif n%2 ==0 :
    print(f"so cach phan tich {n} la :{n//2+1}")
else:
    print(f"so cach phan tich {n} la :{n//2}")   