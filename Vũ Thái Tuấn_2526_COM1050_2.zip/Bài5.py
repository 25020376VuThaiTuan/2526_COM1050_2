# BAI 5 Nhập vào số nguyên dương n. Viết chương trình in ra số 0 tận cùng của giai thừa của n.

n = int(input("nhap so nguyen duong n: "))
a =0 
while n >= 5:
    a += n//5
    n = n//5
print(f"so chu so 0 o cuoi giai thua cua {n}! la: {a}") 
        