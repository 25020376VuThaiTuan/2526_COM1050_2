# BAI 4 Nhập vào số nguyên dương n. Viết chương trình in ra số cách phân tích số n
# thành tổng 3 số nguyên dương liên tiếp không.

a = int(input("nhap so nguyen duong n: "))
if a%3 == 0 and a>=6 :
    print(f"so cach phan tich {a} thanh tong cua ba so nguyen duong lien tiep la :{1}" )
else:
    print(f"so cach phan tich {a} thanh tong cua ba so nguyen duong lien tiep la :{0}")