# BAI 6 Nhập vào số nguyên dương n. Viết chương trình in ra số dấu phẩy cần để ngăn
# cách số đó theo chuẩn biểu diễn số học.

n = int(input("nhap so nguyen duong n: "))
n = str(n)
print((len(n)-1)//3)