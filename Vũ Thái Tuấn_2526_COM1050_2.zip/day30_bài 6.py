# 347 Top K frequency Elenments
class Solution:
    def topoKFrequent(sefl, nums:list[int], k :int) -> list[int]:
        count = {}
        freq = [[]for i in range(len(nums)+1)]
        for i in nums :
            count[i] = 1 +count.get(i,0)
        for key , value in count.items():
            freq[value].append(key)
        res = []
        for i in range(len(freq)-1, 0, -1):
            for n in freq[i]:
                res.append(n)
                if len(res) == k:
                    return res
s = Solution()
print(s.topoKFrequent([1,1,1,2,2,3],2))