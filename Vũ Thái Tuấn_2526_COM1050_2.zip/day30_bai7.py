#1929 Concatenation of Array

class Solution:
    def getConcatenation(self, nums: list[int]) -> list[int]:
        return nums + nums