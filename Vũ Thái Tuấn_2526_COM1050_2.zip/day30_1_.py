# (1TWOSUM)Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.
class Solution(object):
    def twoSum(self, nums, target):
        for i in range(len(nums)) :
            u = target - nums[i] 
            if u in nums[i+1:]:
                j = nums.index(u , i+1)
                return [i, j]