#BAI 1 Nhập vào 3 số nguyên dương a, b, c là 3 cạnh của tam giác. Viết chương trình 
# kiểm tra xem đây là tam giác đều, tam giác cân, tam giác vuông hay tam giác thường.

def tam_giac():
    a,b,c  = map(int, input("nhap so nguyen duong a, b, c: ").split())
    if a==b or b==c or c==a:
        return "tam giac can"
    
    elif a**2 == b**2 + c**2 or b**2 == a**2 + c**2 or c**2 == a**2 + b**2:
        return "tam giac vuong"
    
    elif a+b>c and a+c>b and b+c>a:
        return "tam giac thuong"
    else:
        return "khong phai tam giac"  
print(f"voi 3 so lap thanh mot {tam_giac()}")